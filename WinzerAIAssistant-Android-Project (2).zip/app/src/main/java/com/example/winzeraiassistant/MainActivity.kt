package com.example.winzeraiassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private var statusText by mutableStateOf("প্রস্তুত (Ready)")
    private var heard by mutableStateOf("")
    private var reply by mutableStateOf("")
    private var isListening by mutableStateOf(false)
    private var banglaMode by mutableStateOf(true)
    private var apiKey by mutableStateOf("")
    private var selectedProvider by mutableStateOf("gemini")

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val micGranted = results[Manifest.permission.RECORD_AUDIO] == true
            if (micGranted) {
                startListening()
            } else {
                statusText = "Microphone permission is required to listen"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val prefs = getSharedPreferences("winzer_prefs", MODE_PRIVATE)
        apiKey = prefs.getString("api_key", "") ?: ""
        selectedProvider = prefs.getString("provider", "gemini") ?: "gemini"

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF38BDF8),
                    background = Color(0xFF0F172A),
                    surface = Color(0xFF1E293B)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "WINZER",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Your AI Voice Assistant",
                            color = Color(0xFF94A3B8)
                        )

                        Spacer(modifier = Modifier.height(24.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                        ) {
                            Text(
                                text = "Status: $statusText",
                                modifier = Modifier.padding(16.dp),
                                color = if (isListening) Color(0xFF38BDF8) else Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { onTalkClicked() },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isListening) Color(0xFFEF4444) else MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text(if (isListening) "⏹ Listening... (Tap to stop)" else "🎙 Talk to Winzer")
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { banglaMode = !banglaMode },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (banglaMode) "ভাষা: বাংলা 🇧🇩" else "Language: English 🇺🇸")
                            }
                            OutlinedButton(
                                onClick = {
                                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Telegram Access")
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("AI Brain Config (Gemini / Claude)", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = apiKey,
                                    onValueChange = {
                                        apiKey = it
                                        prefs.edit().putString("api_key", it).apply()
                                    },
                                    label = { Text("API Key (Gemini or Claude)") },
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        if (heard.isNotBlank()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("You: $heard", color = Color(0xFF94A3B8))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Winzer: $reply", color = Color(0xFF38BDF8), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            updateTtsLanguage()
        }
    }

    private fun updateTtsLanguage() {
        val targetLocale = if (banglaMode) Locale("bn", "BD") else Locale.US
        val res = tts?.setLanguage(targetLocale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        updateTtsLanguage()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "winzer_reply")
    }

    private fun onTalkClicked() {
        if (isListening) {
            recognizer?.stopListening()
            isListening = false
            statusText = "Ready"
            return
        }

        val required = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            required.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val missing = required.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            startListening()
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText = "Speech recognition unavailable"
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { statusText = if (banglaMode) "শুনছি..." else "Listening..." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { statusText = if (banglaMode) "ভাবছি..." else "Thinking..." }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onError(error: Int) {
                    isListening = false
                    statusText = "Didn't catch that. Tap and try again."
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) {
                        statusText = "Didn't catch that. Tap and try again."
                        return
                    }
                    heard = text
                    if (apiKey.isBlank()) {
                        val handled = handleCommand(text)
                        finishWith(handled ?: if (banglaMode) "কমান্ড বুঝতে পারিনি। API কী দিয়ে AI চালু করুন।" else "I heard \"$text\". Add an API key for the full AI brain.")
                    } else {
                        statusText = "Thinking..."
                        askAi(text)
                    }
                }
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (banglaMode) "bn-BD" else "en-US")
        }
        isListening = true
        statusText = "Starting..."
        recognizer?.startListening(intent)
    }

    private fun has(t: String, vararg keys: String) = keys.any { t.contains(it) }

    private fun findNumber(s: String): MatchResult? =
        Regex("\\+?\\d[\\d\\s-]{5,}\\d").find(s)

    private fun handleCommand(raw: String): String? {
        val t = raw.lowercase(Locale.ROOT).trim()
        return try {
            when {
                has(t, "flashlight", "torch", "টর্চ", "ফ্ল্যাশ") -> setTorch(!has(t, "off", "বন্ধ"))
                has(t, "volume", "ভলিউম") -> adjustVolume(has(t, "up", "increase", "raise", "বাড়া", "বেশি"))
                has(t, "timer", "টাইমার") -> setTimer(t)
                has(t, "alarm", "অ্যালার্ম", "এলার্ম") -> setAlarm(t)
                has(t, "telegram", "টেলিগ্রাম", "who messaged", "inbox", "ইনবক্স") ||
                        t.startsWith("reply ") || t.startsWith("রিপ্লাই ") -> telegramCommand(raw, t)
                has(t, "call", "কল") -> dial(raw)
                has(t, "sms", "message", "মেসেজ") && findNumber(raw) != null -> composeSms(raw)
                has(t, "camera", "ক্যামেরা") -> start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Opening camera")
                has(t, "wifi", "wi-fi", "ওয়াইফাই") -> start(Intent(Settings.ACTION_WIFI_SETTINGS), "Opening Wi-Fi settings")
                has(t, "bluetooth", "ব্লুটুথ") -> start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Opening Bluetooth settings")
                has(t, "navigate", "directions", "map", "ম্যাপ") -> openMap(t)
                has(t, "what time", "the time", "কয়টা বাজে") -> "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                else -> openOrSearch(raw, t)
            }
        } catch (e: Exception) {
            "Error executing command: ${e.message}"
        }
    }

    private fun telegramCommand(raw: String, t: String): String {
        val replyText = Regex("(?i)^\\s*(?:telegram\\s+|টেলিগ্রাম\\s+)?(?:reply|রিপ্লাই)\\s+(.+)$")
            .find(raw)?.groupValues?.get(1)?.trim()
        if (!replyText.isNullOrBlank()) {
            return WinzerBridge.replyTo(applicationContext, replyText)
        }
        return when {
            has(t, "clear", "মুছে") -> WinzerBridge.clear()
            has(t, "read", "latest", "who messaged", "inbox", "পড়ো") -> WinzerBridge.readInbox()
            has(t, "access", "permission") -> start(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), "Opening notification access")
            else -> "Say: telegram read, or: reply to [Name] [Message]"
        }
    }

    private fun start(intent: Intent, message: String): String {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return message
    }

    private fun setTorch(on: Boolean): String {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Flashlight unavailable"
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on" else "Flashlight off"
    }

    private fun adjustVolume(up: Boolean): String {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        return if (up) "Volume up" else "Volume down"
    }

    private fun setTimer(t: String): String {
        val n = Regex("\\d+").find(t)?.value?.toIntOrNull() ?: return "For how long?"
        val seconds = if (has(t, "second")) n else if (has(t, "hour")) n * 3600 else n * 60
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return start(intent, "Timer started for $n minutes")
    }

    private fun setAlarm(t: String): String {
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(t) ?: return "What time should I set the alarm for?"
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
        val meridiem = m.groupValues[3].lowercase(Locale.ROOT)
        if (meridiem.startsWith("p") && hour < 12) hour += 12
        if (meridiem.startsWith("a") && hour == 12) hour = 0
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return start(intent, "Alarm set for %02d:%02d".format(hour, minute))
    }

    private fun dial(raw: String): String {
        val m = findNumber(raw) ?: return "Specify the phone number to call"
        val number = m.value.filter { it.isDigit() || it == '+' }
        return start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")), "Dialing $number")
    }

    private fun composeSms(raw: String): String {
        val m = findNumber(raw) ?: return "Specify the phone number for SMS"
        val number = m.value.filter { it.isDigit() || it == '+' }
        val body = raw.substring(m.range.last + 1).trim()
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", body)
        return start(intent, "Composing SMS to $number")
    }

    private fun openMap(t: String): String {
        val place = t.replace(Regex("^(navigate to|directions to|map of|show me|map)\\s*"), "").trim()
        if (place.isEmpty()) return "Where do you want to go?"
        return start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))), "Showing $place on map")
    }

    private fun openOrSearch(raw: String, t: String): String? {
        Regex("^(?:open|launch|start)\\s+(.+)$").find(t)?.let { return openApp(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s*(?:খোলো|খুলো|ওপেন করো)$").find(t)?.let { return openApp(it.groupValues[1].trim()) }
        Regex("^(?:search for|search|google)\\s+(.+)$").find(t)?.let {
            return start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1].trim()))), "Searching Google")
        }
        return null
    }

    private fun openApp(name: String): String {
        val aliases = mapOf("ইউটিউব" to "youtube", "ফেসবুক" to "facebook", "টেলিগ্রাম" to "telegram", "ক্যামেরা" to "camera")
        val query = aliases[name] ?: name
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(query) }
            ?: return "App $name not found"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "Cannot open $name"
        startActivity(launch)
        return "Opening ${match.loadLabel(pm)}"
    }

    private fun finishWith(answer: String) {
        reply = answer
        statusText = "Ready"
        speak(answer)
    }

    private fun askAi(userText: String) {
        val key = apiKey.trim()
        val isClaude = selectedProvider == "claude"

        val systemPrompt = """
            You are Winzer, a voice assistant running on the user's Android phone.
            Reply with ONLY a JSON object: {"command": <string or null>, "say": <string>}.
            If the user wants a phone action, set "command" to exactly ONE of these forms:
            open <app name> | open camera | flashlight on | flashlight off | volume up | volume down |
            set timer for <n> minutes | set alarm for <H:MM> am (or pm) | call <digits> | message <digits> <text> |
            wifi settings | bluetooth settings | navigate to <place> | search for <query> | what time is it |
            telegram read | reply to <name> <text> | telegram clear
            Otherwise set "command" to null and put your answer in "say".
            "say" is spoken aloud: keep it under 25 words, plain text, in the user's language.
        """.trimIndent()

        Thread {
            try {
                var responseText = ""
                if (isClaude) {
                    val body = JSONObject()
                        .put("model", "claude-3-5-sonnet-20241022")
                        .put("max_tokens", 300)
                        .put("system", systemPrompt)
                        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userText)))

                    val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        doOutput = true
                        setRequestProperty("content-type", "application/json")
                        setRequestProperty("x-api-key", key)
                        setRequestProperty("anthropic-version", "2023-06-01")
                    }
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                    val res = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    responseText = JSONObject(res).getJSONArray("content").getJSONObject(0).getString("text")
                } else {
                    val geminiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$key"
                    val body = JSONObject()
                        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                        .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", userText)))))

                    val conn = (URL(geminiUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        doOutput = true
                        setRequestProperty("content-type", "application/json")
                    }
                    conn.outputStream.use { it.write(body.toString().toByteArray()) }
                    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                    val res = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    responseText = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                }

                val start = responseText.indexOf('{')
                val end = responseText.lastIndexOf('}')
                val json = if (start >= 0 && end > start) JSONObject(responseText.substring(start, end + 1)) else JSONObject()
                val say = json.optString("say", responseText)
                val cmd = json.optString("command", "")

                runOnUiThread {
                    val executed = if (cmd.isNotBlank()) handleCommand(cmd) else null
                    val spoken = if (cmd.startsWith("telegram") || cmd.startsWith("reply")) (executed ?: say) else say.ifBlank { executed ?: "Done" }
                    finishWith(spoken)
                }
            } catch (e: Exception) {
                runOnUiThread { finishWith(handleCommand(userText) ?: "AI response error: ${e.message}") }
            }
        }.start()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}