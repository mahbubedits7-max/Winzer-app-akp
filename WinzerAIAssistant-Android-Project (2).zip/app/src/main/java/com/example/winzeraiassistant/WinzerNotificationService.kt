package com.example.winzeraiassistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

object WinzerBridge {
    val TELEGRAM_PACKAGES = setOf(
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "org.telegram.plus",
        "org.thunderdog.challegram"
    )

    class Chat(val key: String, var name: String, var action: Notification.Action) {
        val messages = ArrayList<String>()
    }

    private val chats = LinkedHashMap<String, Chat>()

    @Synchronized
    fun addMessage(key: String, name: String, text: String, action: Notification.Action) {
        val chat = chats.remove(key)?.also {
            it.name = name
            it.action = action
        } ?: Chat(key, name, action)

        if (chat.messages.lastOrNull() != text) {
            chat.messages.add(text)
            while (chat.messages.size > 15) chat.messages.removeAt(0)
        }
        chats[key] = chat
        while (chats.size > 25) chats.remove(chats.keys.first())
    }

    @Synchronized
    fun readInbox(): String {
        val unread = chats.values.filter { it.messages.isNotEmpty() }.reversed()
        if (unread.isEmpty()) {
            return "No new Telegram messages. Ensure Notification Access is enabled for Winzer in Settings."
        }
        val sb = StringBuilder()
        sb.append(if (unread.size == 1) "1 person messaged you: " else "${unread.size} people messaged you: ")
        for (c in unread) {
            sb.append("${c.name} says ${c.messages.joinToString(", ")}. ")
        }
        return sb.toString().trim()
    }

    @Synchronized
    fun clear(): String {
        chats.values.forEach { it.messages.clear() }
        return "Cleared."
    }

    @Synchronized
    fun replyTo(context: Context, spoken: String): String {
        val rest = spoken.trim().replaceFirst(Regex("(?i)^(?:to|কে)\\s+"), "").trim()
        if (rest.isEmpty()) return "What should I reply?"

        var best: Chat? = null
        var bestLen = 0
        for (c in chats.values) {
            val names = listOf(c.name.trim(), c.name.trim().split(" ").first())
            for (n in names) {
                if (n.length >= 2 && rest.startsWith(n, ignoreCase = true) && n.length > bestLen) {
                    best = c
                    bestLen = n.length
                }
            }
        }

        if (best != null) {
            val text = rest.substring(bestLen).trimStart(' ', ':', ',', '-').trim()
            if (text.isBlank()) return "What should I tell ${best.name}?"
            return send(context, best, text)
        }

        val waiting = chats.values.filter { it.messages.isNotEmpty() }
        return when {
            waiting.isEmpty() -> "No one has messaged you yet."
            waiting.size == 1 -> send(context, waiting[0], rest)
            else -> "Who should I reply to? Say: reply to [Name] followed by your message."
        }
    }

    private fun send(context: Context, chat: Chat, text: String): String {
        return try {
            val inputs = chat.action.remoteInputs ?: return "This chat does not support direct reply."
            val fill = Intent()
            val results = Bundle()
            for (input in inputs) results.putCharSequence(input.resultKey, text)
            RemoteInput.addResultsToIntent(inputs, fill, results)
            chat.action.actionIntent.send(context, 0, fill)
            chat.messages.clear()
            "Sent to ${chat.name}: $text"
        } catch (e: Exception) {
            "Could not send reply. The notification may have been dismissed."
        }
    }
}

class WinzerNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in WinzerBridge.TELEGRAM_PACKAGES) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = (n.channelId ?: "").lowercase()
            if (channelId.contains("group") || channelId.contains("channel")) return
        }

        val action = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val name = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        WinzerBridge.addMessage(sbn.key, name, text, action)
    }
}