# Winzer AI Voice Assistant (Android)

Multilingual AI Voice Assistant for Android with speech recognition, text-to-speech, Telegram inbox reading and inline replying, and full phone hardware controls.

## Fixes Applied:
1. **Fixed AI Model Error**: Changed invalid model `claude-sonnet-5` to standard `claude-3-5-sonnet-20241022` and added native Google Gemini 3.8 Flash support.
2. **Fixed Missing Permissions**: Added `CAMERA` for flashlight/camera control, `POST_NOTIFICATIONS` for Android 13+, and `SCHEDULE_EXACT_ALARM`.
3. **Fixed Speech & Audio Lifecycle**: Protected against speech listener memory leaks and ensured TTS locale fallback.
4. **Fixed Telegram Notification Reply**: Made RemoteInput bundle extraction null-safe and added fallback for wearable actions.
5. **Fixed Gradle & CI Build**: Configured compatible AGP 8.5.2, Kotlin 1.9.24, Compose 1.5.14, and automated GitHub Actions build.

## How to Build the APK in 2 Minutes:
### Option A: Using GitHub (No Android Studio required!)
1. Create a new GitHub repository (public or private).
2. Push or upload these files to your repository.
3. Click the **Actions** tab in GitHub -> Run workflow "Build Winzer APK".
4. Once completed (approx. 2 min), download your **`winzer-debug-apk`** from Artifacts!

### Option B: Using Android Studio
1. Open Android Studio -> **Open...** -> Select this project folder.
2. Allow Gradle sync to complete with JDK 17.
3. Plug in your Android phone via USB (with Developer options & USB Debugging ON) or launch an emulator.
4. Click the green **Run (▶)** button!
5. In your phone's **Settings > Notifications > Notification access**, turn ON **Winzer**.
